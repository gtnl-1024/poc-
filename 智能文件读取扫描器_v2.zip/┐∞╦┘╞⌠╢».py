#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能文件读取扫描器快速启动脚本
"""

import subprocess
import sys
import os

def check_python_version():
    """检查Python版本"""
    if sys.version_info < (3, 7):
        print("[错误] 需要Python 3.7或更高版本")
        print(f"当前版本: {sys.version}")
        return False
    return True

def install_dependencies():
    """安装依赖"""
    try:
        print("[信息] 检查并安装依赖...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        return True
    except subprocess.CalledProcessError:
        print("[警告] 依赖安装可能存在问题，但继续运行...")
        return True

def main():
    """主函数"""
    print("=" * 50)
    print("    智能文件读取扫描器 v2.0")
    print("    作者: 如烟")
    print("=" * 50)
    print()
    
    # 检查Python版本
    if not check_python_version():
        input("按回车键退出...")
        return
    
    # 安装依赖
    if not install_dependencies():
        input("按回车键退出...")
        return
    
    # 启动主程序
    try:
        print("[信息] 启动主程序...")
        subprocess.run([sys.executable, "main.py"], check=True)
    except subprocess.CalledProcessError as e:
        print(f"[错误] 程序运行出错: {e}")
        input("按回车键退出...")
    except KeyboardInterrupt:
        print("\n[信息] 程序被用户中断")
    except Exception as e:
        print(f"[错误] 未知错误: {e}")
        input("按回车键退出...")

if __name__ == "__main__":
    main()