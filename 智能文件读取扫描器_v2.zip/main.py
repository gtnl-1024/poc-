#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能文件读取扫描器 v2.0
作者：如烟
功能：基于YAML POC的任意文件读取漏洞扫描工具
"""

import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox, simpledialog
import os
import sys
import yaml
import requests
import threading
import time
from urllib.parse import urljoin
import re
import json
import subprocess
import shutil
from datetime import datetime

class SmartFileReadScanner:
    def __init__(self, root):
        self.root = root
        self.root.title("智能文件读取扫描器 v2.0 - by 如烟")
        self.root.geometry("1200x800")
        self.root.minsize(1000, 700)
        
        # 变量初始化
        self.yaml_pocs = {}
        self.current_yaml_content = ""
        self.scan_results = []
        self.is_scanning = False
        
        # 设置样式
        self.setup_styles()
        
        # 创建界面
        self.create_widgets()
        
        # 加载YAML POC
        self.load_yaml_pocs()
        
    def setup_styles(self):
        """设置界面样式"""
        style = ttk.Style()
        style.theme_use('clam')
        
        # 配置颜色主题
        self.colors = {
            'bg': '#f0f0f0',
            'fg': '#333333',
            'button': '#4CAF50',
            'button_hover': '#45a049',
            'success': '#4CAF50',
            'warning': '#ff9800',
            'error': '#f44336',
            'info': '#2196F3'
        }
        
    def create_widgets(self):
        """创建主界面组件"""
        # 创建主框架
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 创建标签页
        self.notebook = ttk.Notebook(main_frame)
        self.notebook.pack(fill=tk.BOTH, expand=True)
        
        # 扫描标签页
        self.scan_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.scan_frame, text="漏洞扫描")
        self.create_scan_tab()
        
        # POC管理标签页
        self.poc_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.poc_frame, text="POC管理")
        self.create_poc_tab()
        
        # POC编辑器标签页
        self.editor_frame = ttk.Frame(self.notebook)
        self.notebook.add(self.editor_frame, text="POC编辑器")
        self.create_editor_tab()
        
        # 状态栏
        self.create_status_bar(main_frame)
        
    def create_scan_tab(self):
        """创建扫描标签页"""
        # 左侧控制面板
        left_frame = ttk.Frame(self.scan_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        
        # URL输入区域
        url_frame = ttk.LabelFrame(left_frame, text="目标设置", padding=10)
        url_frame.pack(fill=tk.X, pady=(0, 10))
        
        ttk.Label(url_frame, text="扫描模式:").pack(anchor=tk.W)
        self.scan_mode = tk.StringVar(value="single")
        ttk.Radiobutton(url_frame, text="单个URL", variable=self.scan_mode, 
                       value="single", command=self.toggle_scan_mode).pack(anchor=tk.W)
        ttk.Radiobutton(url_frame, text="批量URL", variable=self.scan_mode, 
                       value="batch", command=self.toggle_scan_mode).pack(anchor=tk.W)
        
        ttk.Label(url_frame, text="目标URL:").pack(anchor=tk.W, pady=(10, 5))
        self.url_entry = ttk.Entry(url_frame, width=40)
        self.url_entry.pack(fill=tk.X, pady=(0, 5))
        
        self.file_frame = ttk.Frame(url_frame)
        ttk.Label(self.file_frame, text="URL文件:").pack(side=tk.LEFT)
        self.file_entry = ttk.Entry(self.file_frame, width=30)
        self.file_entry.pack(side=tk.LEFT, padx=(5, 5))
        ttk.Button(self.file_frame, text="浏览", command=self.browse_url_file).pack(side=tk.LEFT)
        
        # POC选择区域
        poc_frame = ttk.LabelFrame(left_frame, text="POC选择", padding=10)
        poc_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        ttk.Label(poc_frame, text="可用POC:").pack(anchor=tk.W)
        
        # POC列表和搜索
        search_frame = ttk.Frame(poc_frame)
        search_frame.pack(fill=tk.X, pady=(0, 5))
        self.poc_search = ttk.Entry(search_frame)
        self.poc_search.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.poc_search.bind('<KeyRelease>', self.filter_pocs)
        ttk.Button(search_frame, text="搜索", command=self.filter_pocs).pack(side=tk.RIGHT)
        
        # POC列表
        self.poc_listbox = tk.Listbox(poc_frame, selectmode=tk.MULTIPLE, height=10)
        self.poc_listbox.pack(fill=tk.BOTH, expand=True)
        self.poc_listbox.bind('<Double-Button-1>', self.view_poc_details)
        
        # POC操作按钮
        poc_btn_frame = ttk.Frame(poc_frame)
        poc_btn_frame.pack(fill=tk.X, pady=(5, 0))
        ttk.Button(poc_btn_frame, text="全选", command=self.select_all_pocs).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(poc_btn_frame, text="反选", command=self.deselect_all_pocs).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(poc_btn_frame, text="查看详情", command=self.view_poc_details).pack(side=tk.LEFT)
        
        # 扫描控制
        control_frame = ttk.LabelFrame(left_frame, text="扫描控制", padding=10)
        control_frame.pack(fill=tk.X, pady=(0, 10))
        
        # 扫描参数
        ttk.Label(control_frame, text="线程数:").pack(anchor=tk.W)
        self.thread_count = ttk.Spinbox(control_frame, from_=1, to=50, width=10, increment=1)
        self.thread_count.set(10)
        self.thread_count.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(control_frame, text="超时时间(秒):").pack(anchor=tk.W)
        self.timeout = ttk.Spinbox(control_frame, from_=5, to=60, width=10, increment=5)
        self.timeout.set(30)
        self.timeout.pack(fill=tk.X, pady=(0, 10))
        
        # 扫描按钮
        self.scan_btn = ttk.Button(control_frame, text="开始扫描", command=self.start_scan)
        self.scan_btn.pack(fill=tk.X, pady=(0, 5))
        
        self.stop_btn = ttk.Button(control_frame, text="停止扫描", command=self.stop_scan, state=tk.DISABLED)
        self.stop_btn.pack(fill=tk.X)
        
        # 右侧结果显示区域
        right_frame = ttk.Frame(self.scan_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        # 结果显示
        result_frame = ttk.LabelFrame(right_frame, text="扫描结果", padding=10)
        result_frame.pack(fill=tk.BOTH, expand=True)
        
        # 创建树形视图显示结果
        columns = ('URL', 'POC', '状态', '响应时间', '详情')
        self.result_tree = ttk.Treeview(result_frame, columns=columns, show='tree headings', height=15)
        
        # 设置列标题和宽度
        self.result_tree.heading('#0', text='序号')
        self.result_tree.column('#0', width=50)
        
        for col in columns:
            self.result_tree.heading(col, text=col)
            if col == 'URL':
                self.result_tree.column(col, width=300)
            elif col == '详情':
                self.result_tree.column(col, width=400)
            else:
                self.result_tree.column(col, width=100)
        
        # 添加滚动条
        result_scrollbar = ttk.Scrollbar(result_frame, orient=tk.VERTICAL, command=self.result_tree.yview)
        self.result_tree.configure(yscrollcommand=result_scrollbar.set)
        
        self.result_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        result_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        # 结果操作按钮
        result_btn_frame = ttk.Frame(right_frame)
        result_btn_frame.pack(fill=tk.X, pady=(10, 0))
        
        ttk.Button(result_btn_frame, text="导出结果", command=self.export_results).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(result_btn_frame, text="清空结果", command=self.clear_results).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(result_btn_frame, text="查看详情", command=self.view_result_details).pack(side=tk.LEFT)
        
        # 初始化扫描模式
        self.toggle_scan_mode()
        
    def create_poc_tab(self):
        """创建POC管理标签页"""
        # 左侧POC列表
        left_frame = ttk.Frame(self.poc_frame)
        left_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=(0, 10))
        
        list_frame = ttk.LabelFrame(left_frame, text="YAML POC列表", padding=10)
        list_frame.pack(fill=tk.BOTH, expand=True)
        
        # 搜索框
        search_frame = ttk.Frame(list_frame)
        search_frame.pack(fill=tk.X, pady=(0, 5))
        self.poc_manage_search = ttk.Entry(search_frame)
        self.poc_manage_search.pack(side=tk.LEFT, fill=tk.X, expand=True)
        self.poc_manage_search.bind('<KeyRelease>', self.filter_manage_pocs)
        ttk.Button(search_frame, text="搜索", command=self.filter_manage_pocs).pack(side=tk.RIGHT)
        
        # POC列表
        self.poc_manage_listbox = tk.Listbox(list_frame, height=20)
        self.poc_manage_listbox.pack(fill=tk.BOTH, expand=True)
        self.poc_manage_listbox.bind('<Double-Button-1>', self.load_poc_to_editor)
        
        # POC操作按钮
        poc_btn_frame = ttk.Frame(list_frame)
        poc_btn_frame.pack(fill=tk.X, pady=(5, 0))
        ttk.Button(poc_btn_frame, text="添加POC", command=self.add_new_poc).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(poc_btn_frame, text="编辑POC", command=self.edit_poc).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(poc_btn_frame, text="删除POC", command=self.delete_poc).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(poc_btn_frame, text="刷新列表", command=self.refresh_poc_list).pack(side=tk.LEFT)
        
        # 右侧POC预览
        right_frame = ttk.Frame(self.poc_frame)
        right_frame.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True)
        
        preview_frame = ttk.LabelFrame(right_frame, text="POC预览", padding=10)
        preview_frame.pack(fill=tk.BOTH, expand=True)
        
        self.poc_preview_text = scrolledtext.ScrolledText(preview_frame, height=25, wrap=tk.WORD)
        self.poc_preview_text.pack(fill=tk.BOTH, expand=True)
        
    def create_editor_tab(self):
        """创建POC编辑器标签页 - 按照先测试后生成POC的流程设计"""
        # 创建左右分栏
        paned_window = ttk.PanedWindow(self.editor_frame, orient=tk.HORIZONTAL)
        paned_window.pack(fill=tk.BOTH, expand=True)
        
        # 左侧：测试和响应分析区域
        left_frame = ttk.Frame(paned_window)
        paned_window.add(left_frame, weight=1)
        
        # 测试请求区域
        test_frame = ttk.LabelFrame(left_frame, text="1. 目标测试", padding=10)
        test_frame.pack(fill=tk.X, pady=(0, 10))
        
        # URL输入
        url_frame = ttk.Frame(test_frame)
        url_frame.pack(fill=tk.X, pady=(0, 5))
        ttk.Label(url_frame, text="目标URL:").pack(side=tk.LEFT)
        self.test_url_entry = ttk.Entry(url_frame, width=40)
        self.test_url_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(5, 0))
        
        # 请求方法选择
        method_frame = ttk.Frame(test_frame)
        method_frame.pack(fill=tk.X, pady=(0, 5))
        ttk.Label(method_frame, text="请求方法:").pack(side=tk.LEFT)
        self.request_method = tk.StringVar(value="GET")
        get_radio = ttk.Radiobutton(method_frame, text="GET", variable=self.request_method, value="GET", 
                                  command=self.update_request_method_visibility)
        get_radio.pack(side=tk.LEFT, padx=(5, 0))
        post_radio = ttk.Radiobutton(method_frame, text="POST", variable=self.request_method, value="POST",
                                   command=self.update_request_method_visibility)
        post_radio.pack(side=tk.LEFT, padx=(5, 0))
        
        # 路径输入
        ttk.Label(test_frame, text="请求路径:").pack(anchor=tk.W)
        self.test_path_entry = ttk.Entry(test_frame, width=40)
        self.test_path_entry.pack(fill=tk.X, pady=(0, 5))
        self.test_path_entry.insert(0, "/")
        
        # 请求头输入
        ttk.Label(test_frame, text="请求头 (每行一个，格式: Name: Value):").pack(anchor=tk.W)
        self.test_headers_text = scrolledtext.ScrolledText(test_frame, height=4, wrap=tk.WORD)
        self.test_headers_text.pack(fill=tk.X, pady=(0, 5))
        self.test_headers_text.insert(tk.END, "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36")
        
        # POST数据输入
        self.post_data_frame = ttk.Frame(test_frame)
        ttk.Label(self.post_data_frame, text="POST数据:").pack(anchor=tk.W)
        self.test_post_data = scrolledtext.ScrolledText(self.post_data_frame, height=3, wrap=tk.WORD)
        self.test_post_data.pack(fill=tk.X, pady=(0, 5))
        
        # 发送请求按钮
        ttk.Button(test_frame, text="发送请求", command=self.send_test_request).pack(fill=tk.X)
        
        # 响应信息显示
        response_frame = ttk.LabelFrame(left_frame, text="2. 响应分析", padding=10)
        response_frame.pack(fill=tk.BOTH, expand=True, pady=(0, 10))
        
        # 响应状态
        self.response_status_label = ttk.Label(response_frame, text="等待发送请求...", foreground="gray")
        self.response_status_label.pack(anchor=tk.W, pady=(0, 5))
        
        # 响应内容
        ttk.Label(response_frame, text="响应内容:").pack(anchor=tk.W)
        self.response_text = scrolledtext.ScrolledText(response_frame, height=12, wrap=tk.WORD, font=('Consolas', 9))
        self.response_text.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        # 响应内容选择区域
        content_frame = ttk.LabelFrame(response_frame, text="3. 选择匹配内容", padding=5)
        content_frame.pack(fill=tk.X)
        
        ttk.Label(content_frame, text="从响应内容中选择要作为匹配条件的文本:").pack(anchor=tk.W)
        
        # 选择按钮
        select_frame = ttk.Frame(content_frame)
        select_frame.pack(fill=tk.X, pady=(5, 0))
        
        ttk.Button(select_frame, text="选中内容添加到匹配列表", command=self.add_selected_to_matchers).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(select_frame, text="清空匹配列表", command=self.clear_matchers_list).pack(side=tk.LEFT)
        
        # 已选择的匹配条件列表
        ttk.Label(content_frame, text="已选择的匹配条件:").pack(anchor=tk.W, pady=(5, 0))
        self.selected_matchers_listbox = tk.Listbox(content_frame, height=6)
        self.selected_matchers_listbox.pack(fill=tk.X, pady=(0, 5))
        
        # 右侧：POC生成和编辑区域
        right_frame = ttk.Frame(paned_window)
        paned_window.add(right_frame, weight=1)
        
        # POC生成区域
        poc_gen_frame = ttk.LabelFrame(right_frame, text="4. POC生成", padding=10)
        poc_gen_frame.pack(fill=tk.X, pady=(0, 10))
        
        # POC基本信息
        info_frame = ttk.Frame(poc_gen_frame)
        info_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(info_frame, text="POC名称:").grid(row=0, column=0, sticky=tk.W, padx=(0, 5))
        self.poc_name_entry = ttk.Entry(info_frame, width=30)
        self.poc_name_entry.grid(row=0, column=1, sticky=tk.EW, padx=(0, 5))
        
        ttk.Label(info_frame, text="严重程度:").grid(row=1, column=0, sticky=tk.W, padx=(0, 5))
        self.poc_severity = tk.StringVar(value="high")
        severity_combo = ttk.Combobox(info_frame, textvariable=self.poc_severity, values=["low", "medium", "high", "critical"], width=10, state="readonly")
        severity_combo.grid(row=1, column=1, sticky=tk.W, padx=(0, 5))
        
        info_frame.columnconfigure(1, weight=1)
        
        # 匹配器类型选择
        matcher_frame = ttk.Frame(poc_gen_frame)
        matcher_frame.pack(fill=tk.X, pady=(5, 0))
        
        ttk.Label(matcher_frame, text="匹配器类型:").pack(side=tk.LEFT, padx=(0, 5))
        self.matcher_type = tk.StringVar(value="word")
        ttk.Radiobutton(matcher_frame, text="关键词匹配", variable=self.matcher_type, value="word").pack(side=tk.LEFT, padx=(0, 5))
        ttk.Radiobutton(matcher_frame, text="状态码匹配", variable=self.matcher_type, value="status").pack(side=tk.LEFT, padx=(0, 5))
        
        # 生成POC按钮
        ttk.Button(poc_gen_frame, text="生成POC", command=self.generate_poc_from_response).pack(fill=tk.X, pady=(5, 0))
        
        # YAML编辑器
        editor_frame = ttk.LabelFrame(right_frame, text="5. POC编辑器", padding=10)
        editor_frame.pack(fill=tk.BOTH, expand=True)
        
        # 编辑器工具栏
        toolbar_frame = ttk.Frame(editor_frame)
        toolbar_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Button(toolbar_frame, text="保存POC", command=self.save_poc_from_editor).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(toolbar_frame, text="验证语法", command=self.validate_yaml_syntax).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(toolbar_frame, text="测试POC", command=self.test_generated_poc).pack(side=tk.LEFT, padx=(0, 5))
        
        # YAML编辑器
        self.yaml_editor = scrolledtext.ScrolledText(editor_frame, height=15, wrap=tk.WORD, font=('Consolas', 10))
        self.yaml_editor.pack(fill=tk.BOTH, expand=True)
        self.yaml_editor.bind('<KeyRelease>', self.on_yaml_change)
        
        # 初始化时隐藏POST数据框
        self.update_request_method_visibility()
        
    def create_status_bar(self, parent):
        """创建状态栏"""
        self.status_bar = ttk.Frame(parent)
        self.status_bar.pack(fill=tk.X, pady=(10, 0))
        
        self.status_label = ttk.Label(self.status_bar, text="就绪", relief=tk.SUNKEN, anchor=tk.W)
        self.status_label.pack(side=tk.LEFT, fill=tk.X, expand=True)
        
        self.progress = ttk.Progressbar(self.status_bar, mode='indeterminate')
        self.progress.pack(side=tk.RIGHT, padx=(10, 0))
        
    def toggle_scan_mode(self):
        """切换扫描模式"""
        mode = self.scan_mode.get()
        if mode == "single":
            self.url_entry.pack(fill=tk.X, pady=(0, 5))
            self.file_frame.pack_forget()
        else:
            self.file_frame.pack(fill=tk.X, pady=(0, 5))
            self.url_entry.pack_forget()
            
    def browse_url_file(self):
        """浏览URL文件"""
        filename = filedialog.askopenfilename(
            title="选择URL文件",
            filetypes=[("文本文件", "*.txt"), ("所有文件", "*.*")]
        )
        if filename:
            self.file_entry.delete(0, tk.END)
            self.file_entry.insert(0, filename)
            
    def load_yaml_pocs(self):
        """加载YAML POC文件"""
        poc_dir = os.path.join(os.path.dirname(__file__), "任意文件读取poc")
        if not os.path.exists(poc_dir):
            os.makedirs(poc_dir)
            
        self.yaml_pocs.clear()
        self.poc_listbox.delete(0, tk.END)
        self.poc_manage_listbox.delete(0, tk.END)
        
        for filename in os.listdir(poc_dir):
            if filename.endswith('.yaml') or filename.endswith('.yml'):
                try:
                    filepath = os.path.join(poc_dir, filename)
                    with open(filepath, 'r', encoding='utf-8') as f:
                        poc_content = yaml.safe_load(f)
                        
                    # 检查POC内容是否为空
                    if poc_content is None:
                        print(f"POC文件 {filename} 内容为空，跳过加载")
                        continue
                        
                    # 检查POC是否包含必要字段
                    if not isinstance(poc_content, dict):
                        print(f"POC文件 {filename} 格式不正确，跳过加载")
                        continue
                        
                    # 安全获取POC名称
                    info = poc_content.get('info', {})
                    if info is None:
                        info = {}
                    poc_name = info.get('name', filename)
                    
                    self.yaml_pocs[filename] = {
                        'name': poc_name,
                        'content': poc_content,
                        'filepath': filepath
                    }
                    
                    self.poc_listbox.insert(tk.END, f"{poc_name} ({filename})")
                    self.poc_manage_listbox.insert(tk.END, f"{poc_name} ({filename})")
                    
                except Exception as e:
                    print(f"加载POC文件 {filename} 失败: {e}")
                    
        self.update_status(f"已加载 {len(self.yaml_pocs)} 个POC")
        
    def filter_pocs(self, event=None):
        """过滤POC列表"""
        search_text = self.poc_search.get().lower()
        self.poc_listbox.delete(0, tk.END)
        
        for filename, poc_data in self.yaml_pocs.items():
            poc_name = poc_data['name'].lower()
            if search_text in poc_name or search_text in filename.lower():
                self.poc_listbox.insert(tk.END, f"{poc_data['name']} ({filename})")
                
    def filter_manage_pocs(self, event=None):
        """过滤管理页面的POC列表"""
        search_text = self.poc_manage_search.get().lower()
        self.poc_manage_listbox.delete(0, tk.END)
        
        for filename, poc_data in self.yaml_pocs.items():
            poc_name = poc_data['name'].lower()
            if search_text in poc_name or search_text in filename.lower():
                self.poc_manage_listbox.insert(tk.END, f"{poc_data['name']} ({filename})")
                
    def select_all_pocs(self):
        """全选POC"""
        self.poc_listbox.selection_set(0, tk.END)
        
    def deselect_all_pocs(self):
        """取消全选POC"""
        self.poc_listbox.selection_clear(0, tk.END)
        
    def view_poc_details(self, event=None):
        """查看POC详情"""
        selection = self.poc_listbox.curselection()
        if not selection:
            messagebox.showwarning("警告", "请先选择一个POC")
            return
            
        # 获取选中的POC
        selected_text = self.poc_listbox.get(selection[0])
        filename = selected_text.split('(')[-1].rstrip(')')
        
        if filename in self.yaml_pocs:
            poc_data = self.yaml_pocs[filename]
            
            # 创建详情窗口
            detail_window = tk.Toplevel(self.root)
            detail_window.title(f"POC详情 - {poc_data['name']}")
            detail_window.geometry("800x600")
            
            text_widget = scrolledtext.ScrolledText(detail_window, wrap=tk.WORD)
            text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            
            # 显示YAML内容
            yaml_content = yaml.dump(poc_data['content'], default_flow_style=False, 
                                   allow_unicode=True, indent=2)
            text_widget.insert(tk.END, yaml_content)
            text_widget.config(state=tk.DISABLED)
            
    def start_scan(self):
        """开始扫描"""
        if self.is_scanning:
            return
            
        # 获取目标URL
        urls = []
        if self.scan_mode.get() == "single":
            url = self.url_entry.get().strip()
            if not url:
                messagebox.showwarning("警告", "请输入目标URL")
                return
            urls.append(url)
        else:
            filepath = self.file_entry.get().strip()
            if not filepath or not os.path.exists(filepath):
                messagebox.showwarning("警告", "请选择有效的URL文件")
                return
                
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    urls = [line.strip() for line in f if line.strip()]
            except Exception as e:
                messagebox.showerror("错误", f"读取URL文件失败: {e}")
                return
                
        if not urls:
            messagebox.showwarning("警告", "没有找到有效的URL")
            return
            
        # 获取选中的POC
        selected_indices = self.poc_listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("警告", "请选择要使用的POC")
            return
            
        selected_pocs = []
        for index in selected_indices:
            selected_text = self.poc_listbox.get(index)
            filename = selected_text.split('(')[-1].rstrip(')')
            if filename in self.yaml_pocs:
                selected_pocs.append(self.yaml_pocs[filename])
                
        if not selected_pocs:
            messagebox.showwarning("警告", "没有有效的POC")
            return
            
        # 开始扫描
        self.is_scanning = True
        self.scan_btn.config(state=tk.DISABLED)
        self.stop_btn.config(state=tk.NORMAL)
        self.progress.start()
        
        # 清空之前的结果
        self.clear_results()
        
        # 启动扫描线程
        thread = threading.Thread(target=self.scan_targets, args=(urls, selected_pocs))
        thread.daemon = True
        thread.start()
        
    def stop_scan(self):
        """停止扫描"""
        self.is_scanning = False
        self.scan_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.progress.stop()
        self.update_status("扫描已停止")
        
    def scan_targets(self, urls, pocs):
        """扫描目标"""
        thread_count = int(self.thread_count.get())
        timeout = int(self.timeout.get())
        
        for i, url in enumerate(urls):
            if not self.is_scanning:
                break
                
            self.update_status(f"正在扫描: {url} ({i+1}/{len(urls)})")
            
            for poc in pocs:
                if not self.is_scanning:
                    break
                    
                try:
                    start_time = time.time()
                    result = self.execute_poc(url, poc, timeout)
                    end_time = time.time()
                    
                    response_time = f"{(end_time - start_time):.2f}s"
                    
                    if result['success']:
                        self.add_result(url, poc['name'], "漏洞存在", response_time, result['details'], 
                                      result.get('requests'), result.get('matched_words'))
                    else:
                        self.add_result(url, poc['name'], "未发现漏洞", response_time, result['message'],
                                      result.get('requests'))
                        
                except Exception as e:
                    self.add_result(url, poc['name'], "扫描错误", "N/A", str(e))
                    
        # 扫描完成
        self.root.after(0, self.scan_complete)
        
    def execute_poc(self, url, poc, timeout):
        """执行POC并收集详细回显信息"""
        try:
            # 检查POC是否有效
            if poc is None or not isinstance(poc, dict):
                return {'success': False, 'message': 'POC格式不正确'}
                
            poc_content = poc.get('content')
            if poc_content is None or not isinstance(poc_content, dict):
                return {'success': False, 'message': 'POC内容为空或格式不正确'}
                
            http_requests = poc_content.get('http', [])
            if not http_requests or not isinstance(http_requests, list):
                return {'success': False, 'message': 'POC中没有HTTP请求定义'}
                
            all_requests = []  # 记录所有请求详情
            
            for http_req in http_requests:
                if http_req is None or not isinstance(http_req, dict):
                    continue
                    
                method = http_req.get('method', 'GET')
                paths = http_req.get('path', [])
                headers = http_req.get('headers', {})
                matchers = http_req.get('matchers', [])
                body = http_req.get('body', '')
                
                # 安全检查
                if not paths or not isinstance(paths, list):
                    continue
                    
                for path in paths:
                    if not path:
                        continue
                        
                    # 替换变量
                    target_url = self.replace_variables(path, url)
                    
                    req_start_time = time.time()
                    
                    try:
                        if method.upper() == 'GET':
                            response = requests.get(target_url, headers=headers, timeout=timeout, 
                                                  verify=False, allow_redirects=False)
                        elif method.upper() == 'POST':
                            response = requests.post(target_url, headers=headers, data=body, 
                                                   timeout=timeout, verify=False, allow_redirects=False)
                        else:
                            continue
                            
                        req_end_time = time.time()
                        
                        # 记录请求详情
                        req_info = {
                            'url': target_url,
                            'method': method,
                            'status_code': response.status_code,
                            'response_size': len(response.text),
                            'response_time': req_end_time - req_start_time,
                            'response_headers': dict(response.headers),
                            'response_text': response.text,
                            'matched': False
                        }
                        
                        # 检查匹配器
                        if self.check_matchers(response, matchers):
                            req_info['matched'] = True
                            all_requests.append(req_info)
                            
                            # 提取匹配的关键词
                            matched_words = []
                            for matcher in matchers:
                                if matcher.get('type') == 'word':
                                    words = matcher.get('words', [])
                                    for word in words:
                                        if word and word in response.text:
                                            matched_words.append(word)
                                            
                            return {
                                'success': True,
                                'details': f"状态码: {response.status_code}, 响应长度: {len(response.text)}, 匹配关键词: {matched_words}",
                                'response': response.text,
                                'requests': all_requests,
                                'matched_words': matched_words
                            }
                        else:
                            all_requests.append(req_info)
                            
                    except requests.RequestException as e:
                        # 记录失败的请求
                        req_info = {
                            'url': target_url,
                            'method': method,
                            'status_code': 0,
                            'response_size': 0,
                            'response_time': time.time() - req_start_time,
                            'response_headers': {},
                            'response_text': f"请求失败: {str(e)}",
                            'matched': False,
                            'error': str(e)
                        }
                        all_requests.append(req_info)
                        continue
                        
            return {
                'success': False, 
                'message': '未匹配到漏洞特征',
                'requests': all_requests
            }
            
        except Exception as e:
            return {'success': False, 'message': f'执行错误: {str(e)}'}
            
    def replace_variables(self, text, base_url):
        """替换POC中的变量"""
        text = text.replace('{{BaseURL}}', base_url)
        # 可以添加更多变量替换逻辑
        return text
        
    def check_matchers(self, response, matchers):
        """检查响应是否匹配匹配器"""
        if not matchers or not isinstance(matchers, list):
            return False
            
        for matcher in matchers:
            if matcher is None or not isinstance(matcher, dict):
                continue
                
            matcher_type = matcher.get('type')
            words = matcher.get('words', [])
            condition = matcher.get('condition', 'or')
            
            if matcher_type == 'word':
                if not words or not isinstance(words, list):
                    continue
                    
                matched = False
                for word in words:
                    if word and word in response.text:
                        matched = True
                        if condition == 'or':
                            return True
                        
                if condition == 'and' and matched:
                    return True
                elif condition == 'and' and not matched:
                    return False
                    
            elif matcher_type == 'status':
                status_codes = matcher.get('status', [])
                if status_codes and isinstance(status_codes, list) and response.status_code in status_codes:
                    return True
                    
            elif matcher_type == 'regex':
                patterns = matcher.get('regex', [])
                if patterns and isinstance(patterns, list):
                    for pattern in patterns:
                        if pattern and re.search(pattern, response.text):
                            return True
                        
        return False
        
    def add_result(self, url, poc, status, response_time, details, requests_data=None, matched_words=None):
        """添加扫描结果"""
        self.root.after(0, lambda: self._add_result_gui(url, poc, status, response_time, details, requests_data, matched_words))
        
    def _add_result_gui(self, url, poc, status, response_time, details, requests_data=None, matched_words=None):
        """在GUI中添加结果"""
        item_id = self.result_tree.insert('', tk.END, text=str(len(self.scan_results) + 1))
        self.result_tree.insert(item_id, tk.END, values=(url, poc, status, response_time, details))
        
        # 根据状态设置颜色
        if status == "漏洞存在":
            self.result_tree.set(item_id, '状态', status)
            # 可以设置行颜色，这里简化处理
            
        # 保存详细结果数据
        result_data = {
            'url': url,
            'poc': poc,
            'status': status,
            'response_time': response_time,
            'details': details
        }
        
        # 添加请求详情数据
        if requests_data:
            result_data['requests'] = requests_data
            
        # 添加匹配关键词数据
        if matched_words:
            result_data['matched_words'] = matched_words
            
        self.scan_results.append(result_data)
        
    def scan_complete(self):
        """扫描完成"""
        self.is_scanning = False
        self.scan_btn.config(state=tk.NORMAL)
        self.stop_btn.config(state=tk.DISABLED)
        self.progress.stop()
        
        vulnerable_count = sum(1 for r in self.scan_results if r['status'] == "漏洞存在")
        self.update_status(f"扫描完成! 共扫描 {len(self.scan_results)} 项，发现 {vulnerable_count} 个漏洞")
        
    def clear_results(self):
        """清空结果"""
        for item in self.result_tree.get_children():
            self.result_tree.delete(item)
        self.scan_results.clear()
        
    def export_results(self):
        """导出结果"""
        if not self.scan_results:
            messagebox.showwarning("警告", "没有结果可导出")
            return
            
        filename = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("文本文件", "*.txt"), ("CSV文件", "*.csv"), ("所有文件", "*.*")]
        )
        
        if filename:
            try:
                with open(filename, 'w', encoding='utf-8') as f:
                    if filename.endswith('.csv'):
                        f.write("URL,POC,状态,响应时间,详情\n")
                        for result in self.scan_results:
                            f.write(f"{result['url']},{result['poc']},{result['status']},"
                                   f"{result['response_time']},{result['details']}\n")
                    else:
                        f.write(f"扫描结果导出 - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                        f.write("=" * 80 + "\n\n")
                        
                        for result in self.scan_results:
                            f.write(f"URL: {result['url']}\n")
                            f.write(f"POC: {result['poc']}\n")
                            f.write(f"状态: {result['status']}\n")
                            f.write(f"响应时间: {result['response_time']}\n")
                            f.write(f"详情: {result['details']}\n")
                            f.write("-" * 40 + "\n")
                            
                messagebox.showinfo("成功", f"结果已导出到: {filename}")
                
            except Exception as e:
                messagebox.showerror("错误", f"导出失败: {e}")
                
    def view_result_details(self):
        """查看结果详情 - 增强版，包含详细回显内容"""
        selection = self.result_tree.selection()
        if not selection:
            messagebox.showwarning("警告", "请先选择一个结果")
            return
            
        item = self.result_tree.item(selection[0])
        values = item['values']
        
        # 查找对应的详细结果数据
        scan_result = None
        for result in self.scan_results:
            if (result['url'] == values[0] and 
                result['poc'] == values[1] and 
                result['status'] == values[2]):
                scan_result = result
                break
        
        # 创建详情窗口
        detail_window = tk.Toplevel(self.root)
        detail_window.title("扫描结果详情 - 详细回显")
        detail_window.geometry("900x700")
        
        # 创建notebook用于分页显示
        detail_notebook = ttk.Notebook(detail_window)
        detail_notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        
        # 基本信息标签页
        info_frame = ttk.Frame(detail_notebook)
        detail_notebook.add(info_frame, text="基本信息")
        
        info_text = scrolledtext.ScrolledText(info_frame, wrap=tk.WORD, font=('Consolas', 10))
        info_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        basic_info = f"""=== 基本信息 ===
目标URL: {values[0]}
使用POC: {values[1]}
扫描状态: {values[2]}
响应时间: {values[3]}

扫描详情:
{values[4]}

=== 扩展信息 ===
扫描时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
状态说明: """
        
        if values[2] == "漏洞存在":
            basic_info += "✓ 检测到漏洞，目标可能存在安全风险"
        elif values[2] == "未发现漏洞":
            basic_info += "✗ 未检测到漏洞特征"
        else:
            basic_info += "⚠ 扫描过程中出现错误"
            
        info_text.insert(tk.END, basic_info)
        info_text.config(state=tk.DISABLED)
        
        # 请求详情标签页
        if scan_result and hasattr(scan_result, 'get') and scan_result.get('requests'):
            req_frame = ttk.Frame(detail_notebook)
            detail_notebook.add(req_frame, text="请求详情")
            
            req_text = scrolledtext.ScrolledText(req_frame, wrap=tk.WORD, font=('Consolas', 9))
            req_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
            
            req_text.insert(tk.END, "=== 请求执行详情 ===\n\n")
            
            requests_data = scan_result.get('requests', [])
            for i, req in enumerate(requests_data, 1):
                req_text.insert(tk.END, f"--- 请求 {i} ---\n")
                req_text.insert(tk.END, f"URL: {req.get('url', 'N/A')}\n")
                req_text.insert(tk.END, f"方法: {req.get('method', 'N/A')}\n")
                req_text.insert(tk.END, f"状态码: {req.get('status_code', 'N/A')}\n")
                req_text.insert(tk.END, f"响应时间: {req.get('response_time', 0):.2f} 秒\n")
                req_text.insert(tk.END, f"响应大小: {req.get('response_size', 0)} 字节\n")
                
                if req.get('matched'):
                    req_text.insert(tk.END, "匹配状态: ✓ 匹配成功\n")
                else:
                    req_text.insert(tk.END, "匹配状态: ✗ 未匹配\n")
                
                # 显示响应头
                headers = req.get('response_headers', {})
                if headers:
                    req_text.insert(tk.END, "\n响应头:\n")
                    for key, value in headers.items():
                        req_text.insert(tk.END, f"  {key}: {value}\n")
                
                req_text.insert(tk.END, "\n" + "="*60 + "\n\n")
            
            req_text.config(state=tk.DISABLED)
            
            # 响应内容标签页
            resp_frame = ttk.Frame(detail_notebook)
            detail_notebook.add(resp_frame, text="响应内容")
            
            resp_text = scrolledtext.ScrolledText(resp_frame, wrap=tk.WORD, font=('Consolas', 9))
            resp_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
            
            resp_text.insert(tk.END, "=== 完整响应内容 ===\n\n")
            
            for i, req in enumerate(requests_data, 1):
                resp_text.insert(tk.END, f"--- 请求 {i} 响应内容 ---\n")
                resp_text.insert(tk.END, f"URL: {req.get('url', 'N/A')}\n")
                resp_text.insert(tk.END, f"状态码: {req.get('status_code', 'N/A')}\n\n")
                
                response_content = req.get('response_text', '')
                if response_content:
                    # 限制显示长度，避免界面卡顿
                    if len(response_content) > 5000:
                        response_content = response_content[:5000] + "\n\n... (内容过长，已截断，完整内容请查看原始请求) ..."
                    resp_text.insert(tk.END, response_content)
                else:
                    resp_text.insert(tk.END, "(无响应内容)")
                
                resp_text.insert(tk.END, "\n\n" + "="*60 + "\n\n")
            
            resp_text.config(state=tk.DISABLED)
            
            # 匹配分析标签页
            if scan_result.get('status') == "漏洞存在":
                match_frame = ttk.Frame(detail_notebook)
                detail_notebook.add(match_frame, text="匹配分析")
                
                match_text = scrolledtext.ScrolledText(match_frame, wrap=tk.WORD, font=('Consolas', 10))
                match_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
                
                match_text.insert(tk.END, "=== 漏洞匹配分析 ===\n\n")
                
                matched_words = scan_result.get('matched_words', [])
                if matched_words:
                    match_text.insert(tk.END, "匹配到的关键词:\n")
                    for word in matched_words:
                        match_text.insert(tk.END, f"  ✓ {word}\n")
                else:
                    match_text.insert(tk.END, "未记录匹配关键词信息\n")
                
                match_text.insert(tk.END, f"\n漏洞确认: 目标 {values[0]} 确实存在 {values[1]} 检测的漏洞特征\n")
                match_text.insert(tk.END, f"\n风险等级评估: ")
                
                # 根据POC名称和匹配内容评估风险
                poc_name = values[1].lower()
                if any(keyword in poc_name for keyword in ['critical', 'rce', 'remote code', '命令执行']):
                    match_text.insert(tk.END, "🔴 高危 - 建议立即修复\n")
                elif any(keyword in poc_name for keyword in ['high', 'sql', 'xss', '文件读取']):
                    match_text.insert(tk.END, "🟠 中高危 - 建议尽快修复\n")
                else:
                    match_text.insert(tk.END, "🟡 中等 - 建议关注修复\n")
                
                match_text.insert(tk.END, f"\n修复建议:\n")
                match_text.insert(tk.END, "1. 立即检查相关代码和配置\n")
                match_text.insert(tk.END, "2. 更新相关组件和依赖库\n")
                match_text.insert(tk.END, "3. 加强输入验证和权限控制\n")
                match_text.insert(tk.END, "4. 进行全面的安全测试\n")
                
                match_text.config(state=tk.DISABLED)
        
        # 底部按钮
        btn_frame = ttk.Frame(detail_window)
        btn_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        def copy_details():
            """复制详情到剪贴板"""
            try:
                # 获取当前标签页内容
                current_tab = detail_notebook.select()
                tab_text = detail_notebook.tab(current_tab, "text")
                
                if tab_text == "基本信息":
                    content = info_text.get(1.0, tk.END)
                elif scan_result and scan_result.get('requests'):
                    if tab_text == "请求详情":
                        content = req_text.get(1.0, tk.END)
                    elif tab_text == "响应内容":
                        content = resp_text.get(1.0, tk.END)
                    elif tab_text == "匹配分析":
                        content = match_text.get(1.0, tk.END)
                    else:
                        content = basic_info
                else:
                    content = basic_info
                
                detail_window.clipboard_clear()
                detail_window.clipboard_append(content)
                messagebox.showinfo("成功", "详情已复制到剪贴板")
            except Exception as e:
                messagebox.showerror("错误", f"复制失败: {e}")
        
        def export_details():
            """导出详情到文件"""
            try:
                filename = filedialog.asksaveasfilename(
                    defaultextension=".txt",
                    filetypes=[("文本文件", "*.txt"), ("所有文件", "*.*")],
                    initialname=f"扫描详情_{values[1].replace(' ', '_')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
                )
                
                if filename:
                    with open(filename, 'w', encoding='utf-8') as f:
                        f.write(f"扫描结果详情报告\n")
                        f.write(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                        f.write("="*80 + "\n\n")
                        
                        # 写入基本信息
                        f.write(basic_info)
                        f.write("\n\n")
                        
                        # 写入请求详情
                        if scan_result and scan_result.get('requests'):
                            f.write("=== 详细请求信息 ===\n\n")
                            for i, req in enumerate(scan_result.get('requests', []), 1):
                                f.write(f"请求 {i}:\n")
                                f.write(f"  URL: {req.get('url', 'N/A')}\n")
                                f.write(f"  方法: {req.get('method', 'N/A')}\n")
                                f.write(f"  状态码: {req.get('status_code', 'N/A')}\n")
                                f.write(f"  响应时间: {req.get('response_time', 0):.2f} 秒\n")
                                
                                response_content = req.get('response_text', '')
                                if response_content and len(response_content) <= 2000:
                                    f.write(f"  响应内容:\n{response_content}\n")
                                elif response_content:
                                    f.write(f"  响应内容: (内容过长，请查看原始响应)\n")
                                
                                f.write("\n" + "-"*60 + "\n\n")
                    
                    messagebox.showinfo("成功", f"详情已导出到: {filename}")
            except Exception as e:
                messagebox.showerror("错误", f"导出失败: {e}")
        
        ttk.Button(btn_frame, text="复制详情", command=copy_details).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btn_frame, text="导出详情", command=export_details).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Button(btn_frame, text="关闭", command=detail_window.destroy).pack(side=tk.RIGHT)
        
    def add_new_poc(self):
        """添加新POC"""
        # 切换到编辑器标签页
        self.notebook.select(self.editor_frame)
        self.new_poc_in_editor()
        
    def edit_poc(self):
        """编辑POC"""
        selection = self.poc_manage_listbox.curselection()
        if not selection:
            messagebox.showwarning("警告", "请先选择一个POC")
            return
            
        selected_text = self.poc_manage_listbox.get(selection[0])
        filename = selected_text.split('(')[-1].rstrip(')')
        
        if filename in self.yaml_pocs:
            # 切换到编辑器标签页
            self.notebook.select(self.editor_frame)
            self.load_poc_to_editor()
            
    def delete_poc(self):
        """删除POC"""
        selection = self.poc_manage_listbox.curselection()
        if not selection:
            messagebox.showwarning("警告", "请先选择一个POC")
            return
            
        selected_text = self.poc_manage_listbox.get(selection[0])
        filename = selected_text.split('(')[-1].rstrip(')')
        
        if messagebox.askyesno("确认", f"确定要删除POC '{selected_text}' 吗？"):
            try:
                if filename in self.yaml_pocs:
                    os.remove(self.yaml_pocs[filename]['filepath'])
                    del self.yaml_pocs[filename]
                    
                self.refresh_poc_list()
                messagebox.showinfo("成功", "POC已删除")
                
            except Exception as e:
                messagebox.showerror("错误", f"删除失败: {e}")
                
    def refresh_poc_list(self):
        """刷新POC列表"""
        self.load_yaml_pocs()
        
    def new_poc_in_editor(self):
        """在编辑器中新建POC - Nuclei兼容模板"""
        template = {
            'id': 'custom-poc-' + str(int(time.time())),
            'info': {
                'name': '自定义POC',
                'author': '如烟',
                'severity': 'high',
                'description': '自定义的任意文件读取漏洞POC',
                'tags': 'file-read,custom',
                'reference': ['https://owasp.org/www-project-web-security-testing-guide/'],
                'classification': {
                    'cvss-metrics': 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N',
                    'cvss-score': '7.5',
                    'cwe-id': 'CWE-22'
                }
            },
            'http': [
                {
                    'method': 'GET',
                    'path': ['{{BaseURL}}/path/to/vuln'],
                    'headers': {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                    },
                    'matchers': [
                        {
                            'type': 'word',
                            'words': ['sensitive_content'],
                            'condition': 'or',
                            'part': 'body'
                        }
                    ],
                    'extractors': [
                        {
                            'type': 'regex',
                            'regex': ['sensitive_content[^\\n]*'],
                            'part': 'body'
                        }
                    ]
                }
            ]
        }
        
        # 生成Nuclei兼容格式
        nuclei_template = self.generate_nuclei_compatible_yaml(template)
        if nuclei_template:
            yaml_content = yaml.dump(nuclei_template, default_flow_style=False, 
                                   allow_unicode=True, indent=2, sort_keys=False)
        else:
            # 降级到原始格式
            yaml_content = yaml.dump(template, default_flow_style=False, 
                                   allow_unicode=True, indent=2)
            
        self.yaml_editor.delete(1.0, tk.END)
        self.yaml_editor.insert(tk.END, yaml_content)
        
        self.update_status("已创建Nuclei兼容的POC模板")
        
    def load_poc_to_editor(self, event=None):
        """加载POC到编辑器"""
        # 从管理页面获取选中的POC
        selection = self.poc_manage_listbox.curselection()
        if not selection:
            # 如果管理页面没有选中，尝试从扫描页面获取
            selection = self.poc_listbox.curselection()
            if not selection:
                messagebox.showwarning("警告", "请先选择一个POC")
                return
                
        selected_text = self.poc_manage_listbox.get(selection[0])
        filename = selected_text.split('(')[-1].rstrip(')')
        
        if filename in self.yaml_pocs:
            poc_data = self.yaml_pocs[filename]
            yaml_content = yaml.dump(poc_data['content'], default_flow_style=False, 
                                   allow_unicode=True, indent=2)
            
            self.yaml_editor.delete(1.0, tk.END)
            self.yaml_editor.insert(tk.END, yaml_content)
            
            # 更新预览
            self.poc_preview_text.delete(1.0, tk.END)
            self.poc_preview_text.insert(tk.END, yaml_content)
            
    def save_poc_from_editor(self):
        """从编辑器保存POC - 生成Nuclei兼容格式"""
        try:
            yaml_content = self.yaml_editor.get(1.0, tk.END).strip()
            if not yaml_content:
                messagebox.showwarning("警告", "POC内容不能为空")
                return
                
            # 验证YAML语法
            poc_data = yaml.safe_load(yaml_content)
            if poc_data is None:
                messagebox.showerror("错误", "POC内容为空或格式不正确")
                return
                
            # 生成Nuclei兼容的YAML
            nuclei_poc = self.generate_nuclei_compatible_yaml(poc_data)
            if nuclei_poc is None:
                messagebox.showerror("错误", "无法生成Nuclei兼容的POC格式")
                return
                
            # 安全获取POC名称
            info = nuclei_poc.get('info', {})
            if info is None:
                info = {}
            poc_name = info.get('name', 'unnamed-poc')
            
            filename = f"{poc_name.replace(' ', '-')}.yaml"
            
            # 保存文件
            poc_dir = os.path.join(os.path.dirname(__file__), "任意文件读取poc")
            if not os.path.exists(poc_dir):
                os.makedirs(poc_dir)
            filepath = os.path.join(poc_dir, filename)
            
            # 生成标准YAML格式
            nuclei_yaml_content = yaml.dump(nuclei_poc, default_flow_style=False, 
                                          allow_unicode=True, indent=2, sort_keys=False)
            
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(nuclei_yaml_content)
                
            # 同时保存一份原始格式（用于对比）
            original_filepath = os.path.join(poc_dir, f"original_{filename}")
            with open(original_filepath, 'w', encoding='utf-8') as f:
                f.write(yaml_content)
                
            messagebox.showinfo("成功", f"POC已保存到: {filepath}\n(原始格式已保存到: {original_filepath})")
            
            # 刷新POC列表
            self.load_yaml_pocs()
            
            # 询问是否验证Nuclei兼容性
            if messagebox.askyesno("验证", "是否要验证生成的POC与Nuclei的兼容性？"):
                self.validate_nuclei_compatibility(filepath)
            
        except yaml.YAMLError as e:
            messagebox.showerror("错误", f"YAML语法错误: {e}")
        except Exception as e:
            messagebox.showerror("错误", f"保存失败: {e}")
            
    def validate_yaml_syntax(self):
        """验证YAML语法"""
        try:
            yaml_content = self.yaml_editor.get(1.0, tk.END).strip()
            if not yaml_content:
                messagebox.showwarning("警告", "POC内容不能为空")
                return
                
            poc_data = yaml.safe_load(yaml_content)
            messagebox.showinfo("成功", "YAML语法验证通过")
            
        except yaml.YAMLError as e:
            messagebox.showerror("错误", f"YAML语法错误: {e}")
            
    def on_yaml_change(self, event=None):
        """YAML内容变化时的处理"""
        try:
            yaml_content = self.yaml_editor.get(1.0, tk.END).strip()
            if yaml_content:
                poc_data = yaml.safe_load(yaml_content)
                self.current_yaml_content = poc_data
        except:
            pass
            
    def test_poc(self):
        """测试POC - 增强版，显示详细回显"""
        test_url = self.test_url_entry.get().strip()
        if not test_url:
            messagebox.showwarning("警告", "请输入测试URL")
            return
            
        try:
            yaml_content = self.yaml_editor.get(1.0, tk.END).strip()
            if not yaml_content:
                messagebox.showwarning("警告", "POC内容不能为空")
                return
                
            poc_data = yaml.safe_load(yaml_content)
            if poc_data is None:
                messagebox.showerror("错误", "POC内容为空或格式不正确")
                return
                
            # 安全获取POC名称
            info = poc_data.get('info', {})
            if info is None:
                info = {}
            poc_name = info.get('name', 'Test POC')
            
            # 更新状态
            self.response_status_label.config(text=f"正在测试POC: {poc_name}", foreground="blue")
            self.response_text.delete(1.0, tk.END)
            self.response_text.insert(tk.END, f"=== POC测试开始 ===\n")
            self.response_text.insert(tk.END, f"POC名称: {poc_name}\n")
            self.response_text.insert(tk.END, f"测试URL: {test_url}\n")
            self.response_text.insert(tk.END, f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            self.response_text.insert(tk.END, "\n")
            
            # 显示POC配置信息
            http_requests = poc_data.get('http', [])
            self.response_text.insert(tk.END, f"=== POC配置 ===\n")
            self.response_text.insert(tk.END, f"HTTP请求数量: {len(http_requests)}\n")
            
            for i, http_req in enumerate(http_requests, 1):
                if http_req and isinstance(http_req, dict):
                    method = http_req.get('method', 'GET')
                    paths = http_req.get('path', [])
                    self.response_text.insert(tk.END, f"\n请求 {i}:\n")
                    self.response_text.insert(tk.END, f"  方法: {method}\n")
                    self.response_text.insert(tk.END, f"  路径数量: {len(paths)}\n")
                    for j, path in enumerate(paths, 1):
                        self.response_text.insert(tk.END, f"    路径 {j}: {path}\n")
                    
                    headers = http_req.get('headers', {})
                    if headers:
                        self.response_text.insert(tk.END, f"  请求头:\n")
                        for key, value in headers.items():
                            self.response_text.insert(tk.END, f"    {key}: {value}\n")
                    
                    matchers = http_req.get('matchers', [])
                    if matchers:
                        self.response_text.insert(tk.END, f"  匹配器数量: {len(matchers)}\n")
                        for k, matcher in enumerate(matchers, 1):
                            if matcher and isinstance(matcher, dict):
                                matcher_type = matcher.get('type', 'unknown')
                                self.response_text.insert(tk.END, f"    匹配器 {k}: {matcher_type}\n")
                                
                                if matcher_type == 'word':
                                    words = matcher.get('words', [])
                                    self.response_text.insert(tk.END, f"      关键词: {words}\n")
                                elif matcher_type == 'status':
                                    status_codes = matcher.get('status', [])
                                    self.response_text.insert(tk.END, f"      状态码: {status_codes}\n")
            
            self.response_text.insert(tk.END, f"\n=== 执行测试 ===\n")
            self.root.update()  # 刷新界面显示
            
            # 创建临时POC对象
            temp_poc = {
                'name': poc_name,
                'content': poc_data
            }
            
            # 记录开始时间
            start_time = time.time()
            
            # 执行POC
            result = self.execute_poc_with_details(test_url, temp_poc, 30)
            
            # 计算执行时间
            end_time = time.time()
            execution_time = end_time - start_time
            
            # 显示测试结果
            self.response_text.insert(tk.END, f"\n=== 测试结果 ===\n")
            self.response_text.insert(tk.END, f"执行时间: {execution_time:.2f} 秒\n")
            
            if result['success']:
                self.response_status_label.config(
                    text=f"POC测试成功 - 执行时间: {execution_time:.2f}秒", 
                    foreground="green"
                )
                self.response_text.insert(tk.END, f"结果: ✓ 漏洞存在\n")
                self.response_text.insert(tk.END, f"详情: {result['details']}\n")
                
                if 'requests' in result:
                    self.response_text.insert(tk.END, f"\n=== 请求详情 ===\n")
                    for req_info in result['requests']:
                        self.response_text.insert(tk.END, f"请求: {req_info['url']}\n")
                        self.response_text.insert(tk.END, f"方法: {req_info['method']}\n")
                        self.response_text.insert(tk.END, f"状态码: {req_info['status_code']}\n")
                        self.response_text.insert(tk.END, f"响应大小: {req_info['response_size']} 字节\n")
                        self.response_text.insert(tk.END, f"响应时间: {req_info['response_time']:.2f} 秒\n")
                        
                        if req_info.get('response_headers'):
                            self.response_text.insert(tk.END, f"响应头:\n")
                            for key, value in req_info['response_headers'].items():
                                self.response_text.insert(tk.END, f"  {key}: {value}\n")
                        
                        if req_info.get('response_text'):
                            response_preview = req_info['response_text']
                            if len(response_preview) > 1000:
                                response_preview = response_preview[:1000] + "\n... (内容过长，已截断)"
                            self.response_text.insert(tk.END, f"响应内容:\n{response_preview}\n")
                        
                        self.response_text.insert(tk.END, "-" * 50 + "\n")
                
                # 提取可能的匹配内容
                if 'response' in result:
                    self.extract_response_content(result['response'])
                    
            else:
                self.response_status_label.config(
                    text=f"POC测试完成 - 未发现漏洞 - 执行时间: {execution_time:.2f}秒", 
                    foreground="orange"
                )
                self.response_text.insert(tk.END, f"结果: ✗ 未发现漏洞\n")
                self.response_text.insert(tk.END, f"原因: {result['message']}\n")
                
                if 'requests' in result:
                    self.response_text.insert(tk.END, f"\n=== 请求详情 ===\n")
                    for req_info in result['requests']:
                        self.response_text.insert(tk.END, f"请求: {req_info['url']}\n")
                        self.response_text.insert(tk.END, f"状态码: {req_info['status_code']}\n")
                        self.response_text.insert(tk.END, f"响应时间: {req_info['response_time']:.2f} 秒\n")
                        
                        if req_info.get('response_text'):
                            response_preview = req_info['response_text']
                            if len(response_preview) > 500:
                                response_preview = response_preview[:500] + "\n... (内容过长，已截断)"
                            self.response_text.insert(tk.END, f"响应预览:\n{response_preview}\n")
                        
                        self.response_text.insert(tk.END, "-" * 30 + "\n")
            
            self.response_text.insert(tk.END, f"\n=== 测试完成 ===\n")
            self.response_text.insert(tk.END, f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            
            # 滚动到底部
            self.response_text.see(tk.END)
            
        except Exception as e:
            self.response_status_label.config(text=f"POC测试失败: {str(e)}", foreground="red")
            self.response_text.delete(1.0, tk.END)
            self.response_text.insert(tk.END, f"=== POC测试失败 ===\n")
            self.response_text.insert(tk.END, f"错误信息: {str(e)}\n")
            self.response_text.insert(tk.END, f"时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            
    def execute_poc_with_details(self, url, poc, timeout):
        """执行POC并收集详细信息"""
        try:
            poc_content = poc['content']
            http_requests = poc_content.get('http', [])
            
            if not http_requests or not isinstance(http_requests, list):
                return {'success': False, 'message': 'POC中没有HTTP请求定义'}
                
            all_requests = []  # 记录所有请求详情
            
            for http_req in http_requests:
                if http_req is None or not isinstance(http_req, dict):
                    continue
                    
                method = http_req.get('method', 'GET')
                paths = http_req.get('path', [])
                headers = http_req.get('headers', {})
                matchers = http_req.get('matchers', [])
                
                if not paths or not isinstance(paths, list):
                    continue
                    
                for path in paths:
                    if not path:
                        continue
                        
                    # 替换变量
                    target_url = self.replace_variables(path, url)
                    
                    req_start_time = time.time()
                    
                    try:
                        if method.upper() == 'GET':
                            response = requests.get(target_url, headers=headers, timeout=timeout, 
                                                  verify=False, allow_redirects=False)
                        elif method.upper() == 'POST':
                            data = http_req.get('body', '')
                            response = requests.post(target_url, headers=headers, data=data, 
                                                   timeout=timeout, verify=False, allow_redirects=False)
                        else:
                            continue
                            
                        req_end_time = time.time()
                        
                        # 记录请求详情
                        req_info = {
                            'url': target_url,
                            'method': method,
                            'status_code': response.status_code,
                            'response_size': len(response.text),
                            'response_time': req_end_time - req_start_time,
                            'response_headers': dict(response.headers),
                            'response_text': response.text
                        }
                        all_requests.append(req_info)
                        
                        # 检查匹配器
                        if self.check_matchers(response, matchers):
                            return {
                                'success': True,
                                'details': f"状态码: {response.status_code}, 响应长度: {len(response.text)}",
                                'response': response.text,
                                'requests': all_requests
                            }
                            
                    except requests.RequestException as e:
                        # 记录失败的请求
                        req_info = {
                            'url': target_url,
                            'method': method,
                            'status_code': 0,
                            'response_size': 0,
                            'response_time': time.time() - req_start_time,
                            'response_headers': {},
                            'response_text': f"请求失败: {str(e)}"
                        }
                        all_requests.append(req_info)
                        continue
                        
            return {
                'success': False, 
                'message': '未匹配到漏洞特征',
                'requests': all_requests
            }
            
        except Exception as e:
            return {'success': False, 'message': f'执行错误: {str(e)}'}
            
    def extract_response_content(self, response_text):
        """提取响应内容用于匹配条件生成"""
        # 清空现有的匹配建议（如果有的话）
        # 注意：在新设计中，我们不再自动填充列表，而是让用户手动选择
        
        # 提取可能的敏感信息，用于在响应文本中高亮显示或提示
        patterns = [
            r'root:x:0:0',  # Linux passwd
            r'\[fonts\]',   # Windows ini
            r'127\.0\.0\.1', # Localhost
            r'localhost',
            r'Apache',
            r'nginx',
            r'PHP',
            r'MySQL',
            r'password',
            r'username',
            r'admin',
            r'error',
            r'warning',
            r'exception',
            r'stack trace'
        ]
        
        # 在响应文本中标记找到的模式（可选功能）
        found_patterns = []
        for pattern in patterns:
            matches = re.findall(pattern, response_text, re.IGNORECASE)
            for match in matches:
                if match not in found_patterns:
                    found_patterns.append(match)
                    
        # 提取常见的文件路径
        path_patterns = [
            r'/etc/passwd',
            r'/etc/shadow',
            r'/etc/hosts',
            r'c:\\windows\\',
            r'c:\\boot\.ini',
            r'wwwroot',
            r'htdocs'
        ]
        
        for pattern in path_patterns:
            if re.search(pattern, response_text, re.IGNORECASE):
                if pattern not in found_patterns:
                    found_patterns.append(pattern)
                    
        # 更新状态，提示用户发现的潜在匹配内容
        if found_patterns:
            self.update_status(f"发现 {len(found_patterns)} 个可能的匹配内容，请在响应文本中选择并添加到匹配列表")
        else:
            self.update_status("未发现明显的匹配特征，请手动选择响应内容")
                    
    def generate_matchers(self):
        """生成匹配器 - 基于已选择的匹配条件"""
        # 从selected_matchers_listbox获取已选择的匹配条件
        if self.selected_matchers_listbox.size() == 0:
            messagebox.showwarning("警告", "请先选择要作为匹配条件的内容")
            return
            
        selected_words = [self.selected_matchers_listbox.get(i) for i in range(self.selected_matchers_listbox.size())]
        
        # 生成匹配器配置
        matcher = {
            'type': 'word',
            'words': selected_words,
            'condition': 'or'
        }
        
        # 显示生成的匹配器
        matcher_yaml = yaml.dump(matcher, default_flow_style=False, allow_unicode=True, indent=2)
        
        # 创建匹配器预览窗口
        preview_window = tk.Toplevel(self.root)
        preview_window.title("生成的匹配器")
        preview_window.geometry("500x300")
        
        text_widget = scrolledtext.ScrolledText(preview_window, wrap=tk.WORD)
        text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        text_widget.insert(tk.END, "生成的匹配器配置:\n\n")
        text_widget.insert(tk.END, matcher_yaml)
        
        btn_frame = ttk.Frame(preview_window)
        btn_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        def apply_matcher():
            try:
                # 获取当前YAML内容
                yaml_content = self.yaml_editor.get(1.0, tk.END).strip()
                poc_data = yaml.safe_load(yaml_content)
                
                # 添加匹配器到第一个HTTP请求
                if 'http' in poc_data and poc_data['http']:
                    if 'matchers' not in poc_data['http'][0]:
                        poc_data['http'][0]['matchers'] = []
                    poc_data['http'][0]['matchers'].append(matcher)
                    
                    # 更新编辑器内容
                    updated_yaml = yaml.dump(poc_data, default_flow_style=False, 
                                           allow_unicode=True, indent=2)
                    self.yaml_editor.delete(1.0, tk.END)
                    self.yaml_editor.insert(tk.END, updated_yaml)
                    
                    messagebox.showinfo("成功", "匹配器已应用到编辑器")
                    preview_window.destroy()
                else:
                    messagebox.showwarning("警告", "POC中没有HTTP请求定义")
                    
            except Exception as e:
                messagebox.showerror("错误", f"应用匹配器失败: {e}")
                
        ttk.Button(btn_frame, text="应用到编辑器", command=apply_matcher).pack(side=tk.LEFT)
        ttk.Button(btn_frame, text="关闭", command=preview_window.destroy).pack(side=tk.RIGHT)
        
    def extract_parameters(self):
        """提取参数"""
        messagebox.showinfo("提示", "参数提取功能开发中...")
        
    def apply_to_editor(self):
        """应用到编辑器"""
        self.generate_matchers()
        
    def update_request_method_visibility(self):
        """根据请求方法显示/隐藏相应控件"""
        if self.request_method.get() == "POST":
            self.post_data_frame.pack(fill=tk.X, pady=(0, 5))
        else:
            self.post_data_frame.pack_forget()
            
    def send_test_request(self):
        """发送测试请求"""
        url = self.test_url_entry.get().strip()
        if not url:
            messagebox.showwarning("警告", "请输入目标URL")
            return
            
        path = self.test_path_entry.get().strip()
        if not path:
            messagebox.showwarning("警告", "请输入请求路径")
            return
            
        # 构建完整URL
        if not url.startswith(('http://', 'https://')):
            url = 'http://' + url
        if path.startswith('/'):
            full_url = url + path
        else:
            full_url = url + '/' + path
            
        try:
            # 解析请求头
            headers = {}
            headers_text = self.test_headers_text.get(1.0, tk.END).strip()
            if headers_text:
                for line in headers_text.split('\n'):
                    if ':' in line:
                        key, value = line.split(':', 1)
                        headers[key.strip()] = value.strip()
                        
            # 发送请求
            method = self.request_method.get()
            if method == "GET":
                response = requests.get(full_url, headers=headers, timeout=30, verify=False, allow_redirects=False)
            else:
                post_data = self.test_post_data.get(1.0, tk.END).strip()
                response = requests.post(full_url, headers=headers, data=post_data, timeout=30, verify=False, allow_redirects=False)
                
            # 显示响应信息
            status_text = f"状态码: {response.status_code} | 响应大小: {len(response.text)} 字节 | 响应时间: {response.elapsed.total_seconds():.2f}秒"
            
            if response.status_code == 200:
                self.response_status_label.config(text=status_text, foreground="green")
            elif response.status_code in [301, 302, 303, 307, 308]:
                self.response_status_label.config(text=status_text + f" | 跳转到: {response.headers.get('Location', 'N/A')}", foreground="orange")
            else:
                self.response_status_label.config(text=status_text, foreground="red")
                
            # 显示响应内容
            self.response_text.delete(1.0, tk.END)
            self.response_text.insert(tk.END, f"=== 响应头 ===\n")
            for key, value in response.headers.items():
                self.response_text.insert(tk.END, f"{key}: {value}\n")
            self.response_text.insert(tk.END, f"\n=== 响应体 ===\n")
            self.response_text.insert(tk.END, response.text)
            
            # 自动提取可能的匹配内容
            self.extract_potential_matches(response.text)
            
            # 更新状态
            self.update_status(f"请求完成: {full_url}")
            
        except requests.exceptions.Timeout:
            self.response_status_label.config(text="请求超时", foreground="red")
            self.response_text.delete(1.0, tk.END)
            self.response_text.insert(tk.END, "请求超时，请检查网络连接或增加超时时间")
        except requests.exceptions.ConnectionError:
            self.response_status_label.config(text="连接错误", foreground="red")
            self.response_text.delete(1.0, tk.END)
            self.response_text.insert(tk.END, "连接错误，请检查URL是否正确或目标是否可达")
        except Exception as e:
            self.response_status_label.config(text=f"请求失败: {str(e)}", foreground="red")
            self.response_text.delete(1.0, tk.END)
            self.response_text.insert(tk.END, f"请求失败: {str(e)}")
            
    def extract_potential_matches(self, response_text):
        """从响应文本中提取可能的匹配内容"""
        # 常见的敏感信息模式
        patterns = [
            # Linux系统文件
            (r'root:x:0:0', 'Linux root用户信息'),
            (r'bin:x:1:1', 'Linux系统用户'),
            (r'/etc/passwd', 'passwd文件路径'),
            (r'/etc/shadow', 'shadow文件路径'),
            
            # Windows系统文件
            (r'\[fonts\]', 'Windows配置文件'),
            (r'\[extensions\]', 'Windows扩展配置'),
            (r'for 16-bit app support', 'Windows ini文件'),
            
            # 数据库信息
            (r'mysql', 'MySQL数据库'),
            (r'postgresql', 'PostgreSQL数据库'),
            (r'oracle', 'Oracle数据库'),
            (r'DB_PASSWORD', '数据库密码配置'),
            (r'DB_USER', '数据库用户配置'),
            
            # Web服务器信息
            (r'Apache', 'Apache服务器'),
            (r'nginx', 'Nginx服务器'),
            (r'IIS', 'IIS服务器'),
            
            # 框架信息
            (r'WordPress', 'WordPress框架'),
            (r'Joomla', 'Joomla框架'),
            (r'Drupal', 'Drupal框架'),
            
            # 错误信息
            (r'error', '错误信息'),
            (r'warning', '警告信息'),
            (r'exception', '异常信息'),
            (r'stack trace', '堆栈跟踪'),
            
            # 文件路径
            (r'wwwroot', '网站根目录'),
            (r'htdocs', '网站目录'),
            (r'/var/www/', 'Linux网站目录'),
            (r'c:\\inetpub\\', 'Windows IIS目录'),
        ]
        
        # 清空之前的建议列表（如果有的话）
        # 这里可以添加一个建议列表的UI组件
        
    def add_selected_to_matchers(self):
        """将选中的响应内容添加到匹配条件列表"""
        try:
            selected_text = self.response_text.get(tk.SEL_FIRST, tk.SEL_LAST)
            if selected_text.strip():
                # 清理选中的文本
                cleaned_text = selected_text.strip()
                if len(cleaned_text) > 100:
                    cleaned_text = cleaned_text[:100] + "..."
                    
                self.selected_matchers_listbox.insert(tk.END, cleaned_text)
                self.update_status(f"已添加匹配条件: {cleaned_text}")
            else:
                messagebox.showwarning("警告", "请先在响应内容中选择要添加的文本")
        except tk.TclError:
            messagebox.showwarning("警告", "请先在响应内容中选择要添加的文本")
            
    def clear_matchers_list(self):
        """清空匹配条件列表"""
        self.selected_matchers_listbox.delete(0, tk.END)
        self.update_status("已清空匹配条件列表")
        
    def generate_poc_from_response(self):
        """根据响应内容和选中的匹配条件生成POC"""
        poc_name = self.poc_name_entry.get().strip()
        if not poc_name:
            messagebox.showwarning("警告", "请输入POC名称")
            return
            
        # 获取选中的匹配条件
        selected_matchers = []
        for i in range(self.selected_matchers_listbox.size()):
            selected_matchers.append(self.selected_matchers_listbox.get(i))
            
        if not selected_matchers:
            messagebox.showwarning("警告", "请先选择至少一个匹配条件")
            return
            
        # 获取请求信息
        url = self.test_url_entry.get().strip()
        path = self.test_path_entry.get().strip()
        method = self.request_method.get()
        severity = self.poc_severity.get()
        
        # 解析请求头
        headers = {}
        headers_text = self.test_headers_text.get(1.0, tk.END).strip()
        if headers_text:
            for line in headers_text.split('\n'):
                if ':' in line:
                    key, value = line.split(':', 1)
                    headers[key.strip()] = value.strip()
                    
        # 获取POST数据
        post_data = ""
        if method == "POST":
            post_data = self.test_post_data.get(1.0, tk.END).strip()
            
        # 生成POC模板
        poc_template = {
            'id': f'custom-{poc_name.lower().replace(" ", "-")}',
            'info': {
                'name': poc_name,
                'author': '如烟',
                'severity': severity,
                'description': f'{poc_name} - 自定义POC，基于实际测试结果生成',
                'tags': 'custom,file-read'
            },
            'http': []
        }
        
        # 构建HTTP请求
        http_request = {
            'method': method,
            'path': ['{{BaseURL}}' + path],
            'headers': headers,
            'matchers': []
        }
        
        if method == "POST" and post_data:
            http_request['body'] = post_data
            
        # 添加匹配器
        matcher_type = self.matcher_type.get()
        if matcher_type == "word":
            matcher = {
                'type': 'word',
                'words': selected_matchers,
                'condition': 'or'
            }
        elif matcher_type == "status":
            # 尝试从响应状态标签中提取状态码
            status_text = self.response_status_label.cget("text")
            status_match = re.search(r'状态码: (\d+)', status_text)
            if status_match:
                status_code = int(status_match.group(1))
                matcher = {
                    'type': 'status',
                    'status': [status_code]
                }
            else:
                messagebox.showwarning("警告", "无法获取响应状态码，请使用关键词匹配")
                return
        else:
            messagebox.showwarning("警告", "请选择匹配器类型")
            return
            
        http_request['matchers'].append(matcher)
        poc_template['http'].append(http_request)
        
        # 生成Nuclei兼容的POC
        nuclei_poc = self.generate_nuclei_compatible_yaml(poc_template)
        if nuclei_poc:
            # 转换为YAML并显示在编辑器中
            yaml_content = yaml.dump(nuclei_poc, default_flow_style=False, 
                                   allow_unicode=True, indent=2, sort_keys=False)
            
            self.yaml_editor.delete(1.0, tk.END)
            self.yaml_editor.insert(tk.END, yaml_content)
            
            self.update_status(f"Nuclei兼容POC '{poc_name}' 已生成，请在编辑器中查看和修改")
        else:
            # 降级到原始格式
            yaml_content = yaml.dump(poc_template, default_flow_style=False, 
                                   allow_unicode=True, indent=2)
            
            self.yaml_editor.delete(1.0, tk.END)
            self.yaml_editor.insert(tk.END, yaml_content)
            
            self.update_status(f"POC '{poc_name}' 已生成（原始格式），请在编辑器中查看和修改")
        
    def test_generated_poc(self):
        """测试生成的POC - 使用详细回显"""
        test_url = self.test_url_entry.get().strip()
        if not test_url:
            messagebox.showwarning("警告", "请先发送测试请求以获取目标URL")
            return
            
        # 直接调用test_poc函数，使用相同的详细回显
        self.test_poc()

    def generate_nuclei_compatible_yaml(self, poc_data):
        """生成与Nuclei兼容的标准YAML格式"""
        try:
            # 基本验证和清理
            if not poc_data or not isinstance(poc_data, dict):
                return None
                
            # 提取基本信息
            info = poc_data.get('info', {})
            if not isinstance(info, dict):
                info = {}
                
            # 确保必要字段存在
            nuclei_template = {
                'id': info.get('id', f'custom-{int(time.time())}'),
                'info': {
                    'name': info.get('name', 'Custom POC'),
                    'author': info.get('author', '如烟'),
                    'severity': info.get('severity', 'high'),
                    'description': info.get('description', 'Custom vulnerability detection'),
                    'tags': info.get('tags', 'custom')
                }
            }
            
            # 添加可选的info字段
            optional_fields = ['reference', 'classification', 'metadata']
            for field in optional_fields:
                if field in info and info[field]:
                    nuclei_template['info'][field] = info[field]
            
            # 处理HTTP请求
            http_requests = poc_data.get('http', [])
            if not http_requests or not isinstance(http_requests, list):
                return None
                
            nuclei_template['http'] = []
            
            for http_req in http_requests:
                if not isinstance(http_req, dict):
                    continue
                    
                nuclei_request = {}
                
                # 基本HTTP字段
                method = http_req.get('method', 'GET')
                nuclei_request['method'] = method.upper()
                
                # 处理路径
                paths = http_req.get('path', [])
                if paths and isinstance(paths, list):
                    nuclei_request['path'] = paths
                    
                # 处理请求头
                headers = http_req.get('headers', {})
                if headers and isinstance(headers, dict):
                    nuclei_request['headers'] = headers
                    
                # 处理POST数据
                if method.upper() == 'POST':
                    body = http_req.get('body', '')
                    if body:
                        nuclei_request['body'] = body
                        
                # 处理匹配器 - 确保Nuclei兼容性
                matchers = http_req.get('matchers', [])
                if matchers and isinstance(matchers, list):
                    nuclei_matchers = []
                    
                    for matcher in matchers:
                        if not isinstance(matcher, dict):
                            continue
                            
                        nuclei_matcher = {}
                        matcher_type = matcher.get('type', '')
                        
                        if matcher_type == 'word':
                            words = matcher.get('words', [])
                            if words and isinstance(words, list):
                                nuclei_matcher['type'] = 'word'
                                nuclei_matcher['words'] = words
                                
                                # 添加condition（默认为or）
                                condition = matcher.get('condition', 'or')
                                if condition in ['and', 'or']:
                                    nuclei_matcher['condition'] = condition
                                    
                                # 添加可选的part字段
                                part = matcher.get('part', 'body')
                                if part != 'body':
                                    nuclei_matcher['part'] = part
                                    
                        elif matcher_type == 'status':
                            status_codes = matcher.get('status', [])
                            if status_codes and isinstance(status_codes, list):
                                nuclei_matcher['type'] = 'status'
                                nuclei_matcher['status'] = status_codes
                                
                        elif matcher_type == 'regex':
                            patterns = matcher.get('regex', [])
                            if patterns and isinstance(patterns, list):
                                nuclei_matcher['type'] = 'regex'
                                nuclei_matcher['regex'] = patterns
                                
                                # 添加condition和part
                                condition = matcher.get('condition', 'or')
                                if condition in ['and', 'or']:
                                    nuclei_matcher['condition'] = condition
                                    
                                part = matcher.get('part', 'body')
                                if part != 'body':
                                    nuclei_matcher['part'] = part
                                    
                        elif matcher_type == 'size':
                            size_value = matcher.get('size', 0)
                            if size_value:
                                nuclei_matcher['type'] = 'size'
                                nuclei_matcher['size'] = size_value
                                
                        # 添加内部状态
                        internal = matcher.get('internal', False)
                        if internal:
                            nuclei_matcher['internal'] = True
                            
                        if nuclei_matcher:
                            nuclei_matchers.append(nuclei_matcher)
                    
                    if nuclei_matchers:
                        nuclei_request['matchers'] = nuclei_matchers
                        
                # 处理提取器
                extractors = http_req.get('extractors', [])
                if extractors and isinstance(extractors, list):
                    nuclei_extractors = []
                    
                    for extractor in extractors:
                        if not isinstance(extractor, dict):
                            continue
                            
                        nuclei_extractor = {}
                        extractor_type = extractor.get('type', '')
                        
                        if extractor_type == 'regex':
                            patterns = extractor.get('regex', [])
                            if patterns and isinstance(patterns, list):
                                nuclei_extractor['type'] = 'regex'
                                nuclei_extractor['regex'] = patterns
                                
                                # 添加part和name
                                part = extractor.get('part', 'body')
                                if part != 'body':
                                    nuclei_extractor['part'] = part
                                    
                                name = extractor.get('name')
                                if name:
                                    nuclei_extractor['name'] = name
                                    
                        elif extractor_type == 'kval':
                            keys = extractor.get('kval', [])
                            if keys and isinstance(keys, list):
                                nuclei_extractor['type'] = 'kval'
                                nuclei_extractor['kval'] = keys
                                
                                part = extractor.get('part', 'body')
                                if part != 'body':
                                    nuclei_extractor['part'] = part
                                    
                        elif extractor_type == 'json':
                            json_path = extractor.get('json', [])
                            if json_path and isinstance(json_path, list):
                                nuclei_extractor['type'] = 'json'
                                nuclei_extractor['json'] = json_path
                                
                        elif extractor_type == 'xpath':
                            xpath_expr = extractor.get('xpath', [])
                            if xpath_expr and isinstance(xpath_expr, list):
                                nuclei_extractor['type'] = 'xpath'
                                nuclei_extractor['xpath'] = xpath_expr
                                
                        if nuclei_extractor:
                            nuclei_extractors.append(nuclei_extractor)
                    
                    if nuclei_extractors:
                        nuclei_request['extractors'] = nuclei_extractors
                
                # 添加攻击类型标记
                attack = http_req.get('attack', '')
                if attack:
                    nuclei_request['attack'] = attack
                    
                # 添加payload标记
                payloads = http_req.get('payloads', {})
                if payloads and isinstance(payloads, dict):
                    nuclei_request['payloads'] = payloads
                    
                # 只有包含基本字段的请求才添加
                if 'path' in nuclei_request:
                    nuclei_template['http'].append(nuclei_request)
            
            # 添加变量定义
            variables = poc_data.get('variables', {})
            if variables and isinstance(variables, dict):
                nuclei_template['variables'] = variables
                
            # 添加常量定义
            constants = poc_data.get('constants', {})
            if constants and isinstance(constants, dict):
                nuclei_template['constants'] = constants
                
            self_contained = poc_data.get('self-contained', False)
            if self_contained:
                nuclei_template['self-contained'] = True
                
            return nuclei_template
            
        except Exception as e:
            print(f"生成Nuclei兼容YAML时出错: {e}")
            return None

    def validate_nuclei_compatibility(self, yaml_file):
        """验证POC与Nuclei的兼容性"""
        try:
            # 检查Nuclei是否可用
            nuclei_path = self.find_nuclei_executable()
            if not nuclei_path:
                messagebox.showwarning("警告", "未找到Nuclei可执行文件，无法验证兼容性\n\n请确保Nuclei已安装并在PATH中可用")
                return
                
            # 创建验证窗口
            validate_window = tk.Toplevel(self.root)
            validate_window.title("Nuclei兼容性验证")
            validate_window.geometry("700x500")
            
            # 验证结果显示
            text_widget = scrolledtext.ScrolledText(validate_window, wrap=tk.WORD, font=('Consolas', 9))
            text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            
            text_widget.insert(tk.END, f"=== Nuclei兼容性验证 ===\n")
            text_widget.insert(tk.END, f"POC文件: {yaml_file}\n")
            text_widget.insert(tk.END, f"Nuclei路径: {nuclei_path}\n")
            text_widget.insert(tk.END, f"验证时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            text_widget.insert(tk.END, "\n开始验证...\n\n")
            
            validate_window.update()
            
            # 执行验证命令
            import subprocess
            
            # 1. 语法验证
            text_widget.insert(tk.END, "1. 检查YAML语法...\n")
            validate_window.update()
            
            try:
                result = subprocess.run([nuclei_path, '-validate', yaml_file], 
                                      capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0:
                    text_widget.insert(tk.END, "   ✓ YAML语法验证通过\n")
                else:
                    text_widget.insert(tk.END, f"   ✗ YAML语法验证失败:\n{result.stderr}\n")
            except subprocess.TimeoutExpired:
                text_widget.insert(tk.END, "   ⚠ YAML语法验证超时\n")
            except Exception as e:
                text_widget.insert(tk.END, f"   ⚠ YAML语法验证出错: {e}\n")
            
            validate_window.update()
            
            # 2. 模板信息验证
            text_widget.insert(tk.END, "\n2. 检查模板信息...\n")
            validate_window.update()
            
            try:
                result = subprocess.run([nuclei_path, '-t', yaml_file, '-info'], 
                                      capture_output=True, text=True, timeout=30)
                
                if result.returncode == 0:
                    text_widget.insert(tk.END, "   ✓ 模板信息验证通过\n")
                    text_widget.insert(tk.END, f"   模板详情:\n{result.stdout}\n")
                else:
                    text_widget.insert(tk.END, f"   ✗ 模板信息验证失败:\n{result.stderr}\n")
            except subprocess.TimeoutExpired:
                text_widget.insert(tk.END, "   ⚠ 模板信息验证超时\n")
            except Exception as e:
                text_widget.insert(tk.END, f"   ⚠ 模板信息验证出错: {e}\n")
            
            validate_window.update()
            
            # 3. 检查必要字段
            text_widget.insert(tk.END, "\n3. 检查必要字段...\n")
            validate_window.update()
            
            try:
                with open(yaml_file, 'r', encoding='utf-8') as f:
                    poc_data = yaml.safe_load(f)
                    
                required_fields = ['id', 'info']
                missing_fields = []
                
                for field in required_fields:
                    if field not in poc_data:
                        missing_fields.append(field)
                
                if not missing_fields:
                    text_widget.insert(tk.END, "   ✓ 必要字段检查通过\n")
                else:
                    text_widget.insert(tk.END, f"   ✗ 缺少必要字段: {', '.join(missing_fields)}\n")
                
                # 检查info字段
                if 'info' in poc_data:
                    info = poc_data['info']
                    info_required = ['name', 'author', 'severity']
                    missing_info = []
                    
                    for field in info_required:
                        if field not in info:
                            missing_info.append(field)
                    
                    if not missing_info:
                        text_widget.insert(tk.END, "   ✓ info字段检查通过\n")
                    else:
                        text_widget.insert(tk.END, f"   ⚠ info字段缺少: {', '.join(missing_info)}\n")
                
                # 检查HTTP请求
                if 'http' in poc_data:
                    http_requests = poc_data['http']
                    if isinstance(http_requests, list) and len(http_requests) > 0:
                        text_widget.insert(tk.END, "   ✓ HTTP请求定义检查通过\n")
                        
                        # 检查每个请求
                        for i, req in enumerate(http_requests):
                            if isinstance(req, dict):
                                if 'method' in req and 'path' in req:
                                    text_widget.insert(tk.END, f"   ✓ 请求 {i+1} 格式正确\n")
                                else:
                                    text_widget.insert(tk.END, f"   ⚠ 请求 {i+1} 缺少method或path字段\n")
                            else:
                                text_widget.insert(tk.END, f"   ✗ 请求 {i+1} 格式不正确\n")
                    else:
                        text_widget.insert(tk.END, "   ⚠ HTTP请求列表为空或格式不正确\n")
                else:
                    text_widget.insert(tk.END, "   ⚠ 未找到HTTP请求定义\n")
                    
            except Exception as e:
                text_widget.insert(tk.END, f"   ✗ 字段检查出错: {e}\n")
            
            validate_window.update()
            
            # 4. 总结
            text_widget.insert(tk.END, "\n=== 验证总结 ===\n")
            text_widget.insert(tk.END, "POC已按照Nuclei标准格式生成\n")
            text_widget.insert(tk.END, "建议在实际使用前进行目标测试\n")
            text_widget.insert(tk.END, "如遇到问题，请检查Nuclei版本兼容性\n")
            
            # 底部按钮
            btn_frame = ttk.Frame(validate_window)
            btn_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
            
            def copy_report():
                try:
                    validate_window.clipboard_clear()
                    validate_window.clipboard_append(text_widget.get(1.0, tk.END))
                    messagebox.showinfo("成功", "验证报告已复制到剪贴板")
                except Exception as e:
                    messagebox.showerror("错误", f"复制失败: {e}")
            
            def test_with_target():
                """用测试目标验证POC"""
                test_url = simpledialog.askstring("测试目标", "请输入测试URL:", 
                                                    parent=validate_window)
                if test_url:
                    self.test_poc_with_nuclei(yaml_file, test_url, validate_window)
            
            ttk.Button(btn_frame, text="复制报告", command=copy_report).pack(side=tk.LEFT, padx=(0, 5))
            ttk.Button(btn_frame, text="测试POC", command=test_with_target).pack(side=tk.LEFT, padx=(0, 5))
            ttk.Button(btn_frame, text="关闭", command=validate_window.destroy).pack(side=tk.RIGHT)
            
        except Exception as e:
            messagebox.showerror("错误", f"验证过程出错: {e}")

    def find_nuclei_executable(self):
        """查找Nuclei可执行文件"""
        import shutil
        
        # 检查PATH中是否有nuclei
        nuclei_path = shutil.which('nuclei')
        if nuclei_path:
            return nuclei_path
            
        # 检查常见路径
        common_paths = [
            r"E:\tools\信息收集\快速点\自动化漏洞扫描\nuclei_3.4.7_windows_amd64\nuclei.exe",
            r"C:\Program Files\nuclei\nuclei.exe",
            r"C:\nuclei\nuclei.exe",
            os.path.join(os.getcwd(), "nuclei.exe")
        ]
        
        for path in common_paths:
            if os.path.exists(path):
                return path
                
        return None

    def test_poc_with_nuclei(self, yaml_file, target_url, parent_window):
        """使用Nuclei测试POC"""
        try:
            nuclei_path = self.find_nuclei_executable()
            if not nuclei_path:
                messagebox.showerror("错误", "未找到Nuclei可执行文件")
                return
                
            import subprocess
            
            # 创建测试窗口
            test_window = tk.Toplevel(parent_window)
            test_window.title("Nuclei POC测试")
            test_window.geometry("700x400")
            
            text_widget = scrolledtext.ScrolledText(test_window, wrap=tk.WORD, font=('Consolas', 9))
            text_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
            
            text_widget.insert(tk.END, f"=== Nuclei POC测试 ===\n")
            text_widget.insert(tk.END, f"目标URL: {target_url}\n")
            text_widget.insert(tk.END, f"POC文件: {yaml_file}\n")
            text_widget.insert(tk.END, f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            text_widget.insert(tk.END, "\n正在执行测试...\n\n")
            
            test_window.update()
            
            # 执行Nuclei测试
            try:
                cmd = [nuclei_path, '-t', yaml_file, '-u', target_url, '-json']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
                
                if result.stdout:
                    text_widget.insert(tk.END, "=== 执行结果 ===\n")
                    text_widget.insert(tk.END, result.stdout)
                    
                    # 解析JSON结果
                    lines = result.stdout.strip().split('\n')
                    for line in lines:
                        if line.strip():
                            try:
                                result_data = json.loads(line)
                                if result_data.get('template-id'):
                                    text_widget.insert(tk.END, f"\n✓ 发现漏洞: {result_data.get('info', {}).get('name', 'Unknown')}\n")
                                    text_widget.insert(tk.END, f"  严重程度: {result_data.get('info', {}).get('severity', 'Unknown')}\n")
                            except json.JSONDecodeError:
                                pass
                else:
                    text_widget.insert(tk.END, "未检测到漏洞\n")
                
                if result.stderr:
                    text_widget.insert(tk.END, f"\n=== 错误信息 ===\n")
                    text_widget.insert(tk.END, result.stderr)
                    
            except subprocess.TimeoutExpired:
                text_widget.insert(tk.END, "\n⚠ 测试超时\n")
            except Exception as e:
                text_widget.insert(tk.END, f"\n✗ 测试执行出错: {e}\n")
            
            text_widget.insert(tk.END, f"\n测试完成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            
            # 关闭按钮
            ttk.Button(test_window, text="关闭", command=test_window.destroy).pack(pady=10)
            
        except Exception as e:
            messagebox.showerror("错误", f"测试过程出错: {e}")

    def update_status(self, message):
        """更新状态栏"""
        self.status_label.config(text=message)
        self.root.update_idletasks()

def main():
    """主函数"""
    root = tk.Tk()
    app = SmartFileReadScanner(root)
    root.mainloop()

if __name__ == "__main__":
    main()