# 智能文件读取扫描器 v2.0

![Version](https://img.shields.io/badge/version-2.0-blue.svg)
![Python](https://img.shields.io/badge/python-3.7+-green.svg)
![License](https://img.shields.io/badge/license-MIT-orange.svg)

## 📋 项目概述

智能文件读取扫描器是一款专业的任意文件读取漏洞检测工具，采用YAML格式的POC（Proof of Concept）管理方式，支持自定义POC创建、批量扫描和智能匹配功能。

## ✨ 主要特性

### 🔍 漏洞扫描
- **单URL扫描**：针对单个目标进行精确检测
- **批量扫描**：支持从TXT文件读取URL列表，批量检测多个目标
- **多线程并发**：可自定义线程数，大幅提高扫描效率
- **实时进度显示**：扫描过程中实时显示进度和结果

### 📦 POC管理
- **YAML格式**：采用标准YAML格式存储POC，易于阅读和编辑
- **自动加载**：程序启动时自动加载POC目录下的所有YAML文件
- **智能搜索**：支持按名称快速搜索和过滤POC
- **POC预览**：内置POC内容预览和详情查看功能

### ✏️ POC编辑器
- **可视化编辑**：提供专业的YAML编辑器，支持语法高亮
- **模板创建**：内置POC模板，快速创建新的检测规则
- **语法验证**：实时验证YAML语法，确保配置正确
- **智能匹配**：基于响应内容智能生成匹配条件

### 🧪 调试测试
- **实时测试**：支持对单个URL进行POC测试
- **响应分析**：详细显示HTTP响应信息，辅助POC调试
- **匹配助手**：从响应内容自动提取特征，生成匹配器
- **参数提取**：智能提取可用于匹配的关键参数

## 🚀 快速开始

### 环境要求
- Python 3.7+
- Windows/Linux/macOS

### 安装步骤

1. **克隆或下载项目**
   ```bash
   # 如果使用git
   git clone [项目地址]
   cd 智能文件读取扫描器_v2
   ```

2. **安装依赖**
   ```bash
   pip install -r requirements.txt
   ```

3. **启动程序**
   
   方式一：使用批处理文件（Windows）
   ```bash
   双击 启动器.bat
   ```
   
   方式二：使用Python脚本
   ```bash
   python main.py
   ```
   
   方式三：使用快速启动脚本
   ```bash
   python 快速启动.py
   ```

## 📖 使用指南

### 基本使用流程

1. **选择扫描模式**
   - 单URL模式：直接输入目标URL
   - 批量模式：选择包含URL列表的TXT文件

2. **选择POC**
   - 从POC列表中选择要使用的检测规则
   - 支持多选，可同时使用多个POC

3. **配置参数**
   - 设置线程数（建议1-50）
   - 设置超时时间（建议5-60秒）

4. **开始扫描**
   - 点击"开始扫描"按钮
   - 实时查看扫描结果

### 创建自定义POC

1. **进入编辑器**
   - 切换到"POC编辑器"标签页

2. **创建POC**
   - 点击"新建POC"使用模板
   - 或手动编辑YAML内容

3. **测试POC**
   - 在测试区域输入目标URL
   - 点击"测试POC"验证效果

4. **优化匹配条件**
   - 查看响应内容
   - 使用智能匹配助手生成匹配器

5. **保存POC**
   - 验证语法后保存为YAML文件

## 📁 项目结构

```
智能文件读取扫描器_v2/
├── main.py                    # 主程序文件
├── 快速启动.py                 # 快速启动脚本
├── 启动器.bat                 # Windows启动脚本
├── requirements.txt           # Python依赖列表
├── README.md                  # 项目说明文档
├── 使用说明.md                # 详细使用说明
├── 示例URL列表.txt            # 批量扫描URL示例
├── __pycache__/               # Python缓存目录
└── 任意文件读取poc/           # POC存储目录
    ├── 示例-通用文件读取.yaml  # 通用文件读取POC示例
    ├── juhecurl-ssrf-file-read.yaml
    ├── CVE-畅捷-tplus-sql注入.yaml
    └── ...                   # 更多POC文件
```

## 🔧 YAML POC格式

```yaml
id: poc-unique-id
info:
  name: POC名称
  author: 作者
  severity: high          # 严重程度: low/medium/high/critical
  description: POC描述
  tags: file-read,ssrf    # 标签
http:
  - method: GET           # 请求方法
    path:                 # 请求路径
      - "{{BaseURL}}/path"
    headers:              # 请求头
      User-Agent: Mozilla/5.0...
    matchers:             # 匹配器
      - type: word        # 匹配类型
        words:            # 关键词
          - "sensitive_content"
        condition: or     # 匹配条件
```

### 支持的匹配器类型
- **word**: 关键词匹配
- **regex**: 正则表达式匹配  
- **status**: HTTP状态码匹配
- **size**: 响应大小匹配

### 支持的变量
- `{{BaseURL}}`: 目标基础URL
- `{{rand_base(n)}}`: 生成n位随机字符串

## 🛡️ 安全声明

⚠️ **重要提醒**：
- 本工具仅供**安全研究**和**授权测试**使用
- 使用前请确保已获得目标系统的**明确授权**
- 禁止对未授权目标进行测试，否则后果自负
- 作者不对工具的滥用承担任何责任

## 📊 性能优化

- **线程数设置**：建议根据网络状况和目标承受能力调整
- **超时设置**：网络较慢时可适当增加超时时间
- **POC选择**：根据目标特征选择合适的POC，提高检测效率
- **批量扫描**：大量URL时建议分批扫描，避免资源耗尽

## 🐛 常见问题

### Q: 程序无法启动？
A: 检查Python版本是否为3.7+，确保依赖包正确安装。

### Q: POC加载失败？
A: 检查YAML文件语法，确保文件编码为UTF-8。

### Q: 扫描结果不准确？
A: 检查POC匹配条件，确认目标是否有防护措施。

### Q: 如何贡献POC？
A: 创建符合格式的YAML文件，测试验证后提交。

## 🤝 贡献指南

欢迎提交Issue和Pull Request来改进项目：

1. Fork本项目
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 开启Pull Request

## 📄 许可证

本项目采用MIT许可证 - 查看 [LICENSE](LICENSE) 文件了解详情。

## 👥 作者

**如烟** - 安全研究员，渗透测试工程师

## 🙏 致谢

- 感谢所有贡献者和用户的支持
- 参考了多个开源安全工具的设计理念
- 特别感谢Nuclei项目提供的POC格式规范

---

⭐ 如果这个项目对您有帮助，请给它一个星标！

📧 联系方式：如有问题或建议，欢迎提交Issue或联系作者。