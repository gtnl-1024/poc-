#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
POC加载测试脚本
"""

import os
import yaml

def test_poc_loading():
    """测试POC加载功能"""
    poc_dir = "任意文件读取poc"
    success_count = 0
    error_count = 0
    
    print("=" * 50)
    print("POC文件加载测试")
    print("=" * 50)
    
    if not os.path.exists(poc_dir):
        print(f"[错误] POC目录不存在: {poc_dir}")
        return
        
    for filename in os.listdir(poc_dir):
        if filename.endswith('.yaml') or filename.endswith('.yml'):
            filepath = os.path.join(poc_dir, filename)
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    poc_content = yaml.safe_load(f)
                    
                if poc_content is None:
                    print(f"[错误] {filename}: 文件内容为空")
                    error_count += 1
                    continue
                    
                if not isinstance(poc_content, dict):
                    print(f"[错误] {filename}: 文件格式不正确")
                    error_count += 1
                    continue
                    
                # 检查必要字段
                poc_id = poc_content.get('id', 'N/A')
                info = poc_content.get('info', {})
                if info:
                    poc_name = info.get('name', 'N/A')
                    severity = info.get('severity', 'N/A')
                else:
                    poc_name = 'N/A'
                    severity = 'N/A'
                    
                print(f"[成功] {filename}")
                print(f"  ID: {poc_id}")
                print(f"  名称: {poc_name}")
                print(f"  严重程度: {severity}")
                
                # 检查HTTP请求
                http_requests = poc_content.get('http', [])
                print(f"  HTTP请求数量: {len(http_requests)}")
                
                success_count += 1
                
            except Exception as e:
                print(f"[错误] {filename}: {e}")
                error_count += 1
                
            print("-" * 30)
            
    print("=" * 50)
    print(f"测试完成: 成功 {success_count} 个，失败 {error_count} 个")
    print("=" * 50)

if __name__ == "__main__":
    test_poc_loading()